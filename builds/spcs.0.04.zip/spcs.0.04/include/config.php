<?php

	$results_per_page = 20;

	$calibre_db = "/files/eBooks/metadata.db";

	$books_folder = "/files/eBooks/";

	$book_type = "mobi";

	$from = "myemail@gmail.com";

	$config=array(
		'host'      => 'ssl://smtp.googlemail.com',
		'port'      => 465,
		'auth'      => true,
		'username'  => 'username',
		'password'  => 'password'
	);

?>
